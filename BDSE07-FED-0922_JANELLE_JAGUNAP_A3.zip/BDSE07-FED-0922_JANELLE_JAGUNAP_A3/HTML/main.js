const module1Task = document.getElementById('module1');
const module2Task = document.getElementById('module2');
const module3Task = document.getElementById('module3');
const module4Task = document.getElementById('module4');
const module5Task = document.getElementById('module5');
const module6Task = document.getElementById('module6');
const deselectBtn = document.getElementById('deselect');
const taskContainer = document.querySelector('.task__container');
const scheduleContainer = document.querySelector('.schedule__container');
const resetBtn = document.querySelector('.deleteBtn');
const popUp = document.querySelector('.pop-up__container');
const noBtn = document.getElementById('btn__no');
const yesBtn = document.getElementById('btn__yes');


let selectedColor, active

// events listeners
taskContainer.addEventListener('click', selectTask);
scheduleContainer.addEventListener('click', setColors);
deselectBtn.addEventListener('click', resetTasks);
resetBtn.addEventListener('click', openPopup);
noBtn.addEventListener('click', closePopup);
yesBtn.addEventListener('click', deleteTasks);

//task click
function selectTask(e){
    resetTasks();

    taskColor = e.target.style.backgroundColor;

    switch(e.target.id){
        case 'module1':
            activeTask(module1Task, taskColor);
            icon = '<i class="fas fa-check-circle"></i>'
            break
        case 'module2':
            activeTask(module2Task, taskColor);
            icon = '<i class="fas fa-check-circle"></i>'
            break
        case 'module3':
            activeTask(module3Task, taskColor);
            icon = '<i class="fas fa-check-circle"></i>'
            break
        case 'module4':
            activeTask(module4Task, taskColor);
            icon = '<i class="fas fa-check-circle"></i>'
            break
        case 'module5':
            activeTask(module5Task, taskColor);
            icon = '<i class="fas fa-check-circle"></i>'
            break
        case 'module6':
            activeTask(module6Task, taskColor);
            icon = '<i class="fas fa-check-circle"></i>'
            break

    }
}

// set colors for schedule
function setColors(e){
    if(e.target.classList.contains('task') && active === true){
        e.target.style.backgroundColor = selectedColor;
        e.target.innerHTML = icon;
    }
}

// select task
function activeTask(task, color){
    task.classList.toggle('selected');

    if(task.classList.contains('selected')){
        active = true;
        selectedColor = color;
        return selectedColor;
    } else {
        active = false;
    }
}


// reset task
function resetTasks(){
    const allTasks = document.querySelectorAll('.task__name');

    allTasks.forEach((item)=>{
        item.className = 'task__name';
    })
}

// delete task
function deleteTasks(){
    const tasks = document.querySelectorAll('.task');

    tasks.forEach((item)=>{
        item.innerHTML = '';
        item.style.backgroundColor = 'white';
    })
}

//open pop-up
function openPopup(){
    popUp.style.display = 'flex';
}

//close pop-up
function closePopup(){
    popUp.style.display = 'none';
}